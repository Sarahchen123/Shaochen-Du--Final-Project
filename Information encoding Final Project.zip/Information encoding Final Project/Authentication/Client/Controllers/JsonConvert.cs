﻿using System;

namespace Client.Controllers
{
    internal class JsonConvert
    {
        internal static object DeserializeObject<T>(string responseString)
        {
            throw new NotImplementedException();
        }
    }
}